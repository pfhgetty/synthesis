﻿
public interface InventorSkeletalJoint
{
    SkeletalJoint GetWrapped();

    void DetermineLimits();
}
