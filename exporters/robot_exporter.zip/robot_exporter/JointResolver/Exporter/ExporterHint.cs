﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public struct ExporterHint
{

    public bool Convex;

    public bool MultiColor;

    public bool HighResolution;

}
